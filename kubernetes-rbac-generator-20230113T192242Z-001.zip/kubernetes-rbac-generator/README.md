# KubeRBAC
# Kubernetes RBAC / Config Generator

### Prepare Environment:
```bash
$ mkdir /var/lib/devops-codes/
$ cd /var/lib/devops-codes/
$ git clone https://bitbucket.kapitalbank.az/scm/dev/kubernetes-rbac-generator.git
$ chmod +x ./kubernetes-rbac-generator/kube-rbac.sh
```
Create alias for it:
- If you're using bash:
```bash
$ echo "alias kube-rbac="/var/lib/devops-codes/kubernetes-rbac-generator/kube-rbac.sh"" >> ~/.bashrc && source ~/.bashrc
```
- If you're using zsh:
```bash
$ echo "alias kube-rbac="/var/lib/devops-codes/kubernetes-rbac-generator/kube-rbac.sh"" >> ~/.zshrc && source ~/.zshrc
```
- Example: Create `KUBECONFIG` file for user `developer` to get default permissions in `birbank` namespace
```bash
$ kube-rbac create --username developer --namespace birbank -r 0
```
### P.S For detail information just execute:
```bash
$ kube-rbac --help
```
